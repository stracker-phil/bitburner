import * as Common from 'common.js';
import * as Server from 'server.js';
import * as Player from 'player.js';

/**
 * Player instance.
 */
const player = Player.get();

/**
 * Target of our attack.
 */
let target;

/** 
 * Centralized monitoring script, that runs in a
 * single thread on the "home" server. 
 * 
 * It monitors the attacked servers' stats in
 * an interval and decides on whether to hack, 
 * weaken or grow the target server during the 
 * next interval.
 * 
 * The decission is transported to the 
 * distributed worker nodes via the ctrl.js
 * mechanism.
 * 
 * @param {NS} ns
 */
export async function main(ns) {
	/**
	 * The main netscript API interface must be
	 * available in all functions.
	 * 
	 * @param {NS} ns
	 */
	window.ns = ns;

	Server.add('home', []);

	while (true) {
		config = Common.getConfig(ns);
		player.refresh();

		selectTarget();
		if (!target || !target.get('hostname')) {
			Common.say(ns, 'Error: Invalid target')
			await ns.sleep(10000);
		}

		await prepareTarget();

		// HACK!

		await ns.sleep(10000);
	}
}

/**
 * Selects the attacked target server, either by using
 * the fixed target from the config file, or by
 * calculating the most profitable server.
 */
function selectTarget() {
	const prevTarget = config.target;

	if (config.autoPick) {
		target = Server.byProfit();
		config.target = target.get('hostname');
	}

	if (prevTarget !== config.target) {
		Common.say(ns, 'New target selected', config.target);
	}
}

/**
 * Prepares the attack target to be within optimal
 * parameters to be hacked.
 */
async function prepareTarget() {
	do {
		const task = needPreparation();

		if (1 === task) {
			// Focus on weaken.
			await instructWorkers(100, 0);
		} else if (2 === task) {
			// Focus on grow.
			await instructWorkers(35, 65);
		}
	} while (task > 0);
}

/**
 * Determines, if the target server is ready to be
 * hacked, or if it needs to be prepared for max profit.
 * 
 * @retrn {int} 0 .. server is ready to be hacked
 *              1 .. security is too high
 *              2 .. money is too low
 */
function needPreparation() {
	target.refreshStats();

	const maxSec = parseFloat(
		(target.get('minDifficulty') + config.boundSec).toFixed(4)
	);
	const minMoney = parseInt(
		target.get('moneyMax') * config.boundMoney
	);

	if (target.get('hackDifficulty') > maxSec) {
		Common.log(ns, 'Prepare Target: Security too high');
		return 1;
	}

	if (target.get('moneyAvailable') < minMoney) {
		Common.log(ns, 'Prepare Target: Money too low');
		return 2;
	}

	return 0;
}

/**
 * Instructs all servers to allocate the specified
 * percentage of worker types.
 */
async function instructWorkers(pctWeaken, pctGrow) {
	await Server.all(server => {
		server.setWorkers(pctWeaken, pctGrow);
	});
}