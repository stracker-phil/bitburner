import * as Common from 'common.js';
import * as Player from 'player.js';

/**
 * List of all Server instances.
 */
let servers = {};

/**
 * List of services that need to constantly run
 * on the home server.
 */
const serviceFiles = [
	'sync.js',
	'chk.js',
	'grow.js',
];

/**
 * List of remote worker scripts that need to be
 * installed on each worker node.
 */
const toolFiles = [
	'run-hack.js',
	'run-grow.js',
	'run-weaken.js',
];

/**
 * Add a new server to the server list.
 * When the server already exists, nothing happens.
 */
export function add(host, route, _ns) {
	if (_ns && !window.ns) {
		window.ns = _ns;
	}

	if (!servers[host]) {
		new Server(host, route);
	}

	return servers[host];
}

/**
 * Runs a callback against every known server.
 */
export async function all(callback) {
	for (let i = 0; i < servers.length; i++) {
		await callback(servers[i]);
	}
}

/**
 * Flushes the server list.
 */
export function flush() {
	Player.flush();
	servers = {};
}

/**
 * Return a server instance by host name.
 */
export function get(host, stat) {
	const server = servers[host];

	if (server && stat) {
		return server.get(stat);
	} else {
		return server;
	}
}

/**
 * Purchase a new server with the given amount of RAM.
 */
export function purchase(host, ram) {
	const res = ns.purchaseServer(host, ram);

	if (res) {
		const server = add(res, ['home']);
		server.installTools();
	}

	return !!res;
}

/**
 * Delete the specified server
 */
export function upgrade(host, ram) {
	ns.killall(host);

	if (ns.deleteServer(host)) {
		return purchase(host, ram);
	} else {
		return false;
	}
}

/**
 * Return the most profitable server for hacking.
 */
export function byProfit() {
	const player = Player.get(ns);
	let selected = null;

	servers.forEach(server => {
		if (server.requiredHackingSkill > player.hacking) {
			return;
		}

		if (!selected || selected.profitRating < server.profitRating) {
			selected = server;
		}
	});

	return selected;
}

class Server {
	/**
	 * Initialize the new Server instance.
	 */
	constructor(host, route) {
		servers[host] = this;

		this.hostname = host;
		this.route = route;

		this.refresh();
		this.refreshConnections();
	}

	/**
	 * Refresh all server details.
	 */
	refresh() {
		const info = ns.getServer(this.hostname);

		// Initial server security level (i.e. security level when the server was created)
		this.baseDifficulty = info.baseDifficulty;
		// How many CPU cores this server has. Maximum of 8. Affects magnitude of grow and weaken.
		this.cpuCores = info.cpuCores;
		// IP Address. Must be unique
		this.ip = info.ip;
		// Minimum server security level that this server can be weakened to
		this.minDifficulty = info.minDifficulty;
		// Maximum amount of money that this server can hold
		this.moneyMax = info.moneyMax;
		// Number of open ports required in order to gain admin/root access
		this.numOpenPortsRequired = info.numOpenPortsRequired;
		// Name of company/faction/etc. that this server belongs to. Optional, not applicable to all Servers
		this.organizationName // string = info.organizationName // string;
		// Flag indicating whether this is a purchased server
		this.purchasedByPlayer = info.purchasedByPlayer;
		// Hacking level required to hack this server
		this.requiredHackingSkill = info.requiredHackingSkill;
		// Parameter that affects how effectively this server's money can be increased using the grow() Netscript function
		this.serverGrowth = info.serverGrowth;

		this.refreshAccess();
		this.refreshRam();
		this.refreshStats();
	}

	/**
	 * Refreshes the list of open ports/root access flag.
	 */
	refreshAccess() {
		const info = ns.getServer(this.hostname);

		// Flag indicating whether player is curently connected to this server
		this.isConnectedTo = info.isConnectedTo;
		// Flag indicating whether this server has a backdoor installed by a player
		this.backdoorInstalled = info.backdoorInstalled;
		// Flag indicating whether the FTP port is open
		this.ftpPortOpen = info.ftpPortOpen;
		// Flag indicating whether player has admin/root access to this server
		this.hasAdminRights = info.hasAdminRights;
		// Flag indicating whether HTTP Port is open
		this.httpPortOpen = info.httpPortOpen;
		// How many ports are currently opened on the server
		this.openPortCount = info.openPortCount;
		// Flag indicating whether SMTP Port is open
		this.smtpPortOpen = info.smtpPortOpen;
		// Flag indicating whether SQL Port is open
		this.sqlPortOpen = info.sqlPortOpen;
		// Flag indicating whether the SSH Port is open
		this.sshPortOpen = info.sshPortOpen;
	}

	/**
	 * Refresh details about the servers RAM usage.
	 */
	refreshRam() {
		// RAM (GB) available on this server
		this.ramMax = ns.getServerRam(this.hostname);
		// RAM (GB) used. i.e. unavailable RAM
		this.ramUsed = ns.getServerUsedRam(this.hostname);
		// RAM (GB) free. i.e. available RAM
		this.ramFree = this.ramMax - this.ramUsed;
	}

	/**
	 * Refresh details about the servers attack stats.
	 * 
	 * The times change after each hack/grow/weaken call
	 * and need to be refreshed constantly.
	 */
	refreshStats() {
		// Server Security Level
		this.hackDifficulty = ns.getServerSecurityLevel(this.hostname);
		// How much money currently resides on the server and can be hacked
		this.moneyAvailable = ns.getServerMoneyAvailable(this.hostname);

		this.timeHack = ns.getHackTime(this.hostname);
		this.timeGrow = ns.getGrowTime(this.hostname);
		this.timeWeaken = ns.getWeakenTime(this.hostname);

		this.refreshRating();
	}

	/**
	 * Re-calculates the profit rating of this server, which
	 * is used to determine the most suitable server for attacking.
	 */
	refreshRating() {
		this.profitRating = 0;

		if (
			!this.hasAdminRights
			|| this.purchasedByPlayer
			|| !this.hackDifficulty
			|| !this.minDifficulty
		) {
			return;
		}

		const rateMoney = this.moneyMax + this.moneyAvailable / 10;
		const avgTime = (this.timeGrow + this.timeHack + 2 * this.timeWeaken) / 4;
		const minTime = avgTime / this.hackDifficulty * this.minDifficulty;

		this.profitRating = rateMoney / minTime;
	}

	/**
	 * Scan for connected servers and store a list of
	 * available server names in the "connections" property.
	 */
	refreshConnections() {
		// An array containing the hostnames of all servers that are one node way from this server.
		this.connections = ns.scan(this.hostname);

		// Create instances of all connected servers.
		this.connections.forEach(host => {
			const route = [...this.route, this.hostname];
			add(host, route);
		});
	}

	/**
	 * Getter for all server attributes.
	 */
	get(key) {
		return this[key];
	}

	/**
	 * Opens all ports on the server and establishes root
	 * access. If possible, also installs the backdoor
	 */
	access() {
		if (this.purchasedByPlayer) {
			return;
		}

		let changed = false;
		const player = Player.get(ns);

		player.portOpeners(tool => {
			if (!this.get([tool.port])) {
				ns[tool.cmd](this.hostname);
				changed = true;
			}
		});

		if (changed) {
			this.refreshAccess();
		}

		if (
			this.numOpenPortsRequired > this.openPortCount
			|| this.requiredHackingSkill > player.hacking
		) {
			return;
		}

		if (!this.hasAdminRights) {
			ns.nuke(this.hostname);

			this.refreshAccess();
		}

		if (this.hasAdminRights && !this.backdoorInstalled) {
			// TODO: Requires NS-4
			// ns.installBackdoor(this.hostname);
		}
	}

	/**
	 * Installs hacking tools on this server.
	 */
	async installTools() {
		if ('home' === this.hostname) {
			return;
		}

		// Try to establish root access.
		this.access();

		if (!this.hasAdminRights) {
			return false;
		}

		// Copy/Replace tools to remote server.
		for (let i = 0; i < toolFiles.length; i++) {
			const script = toolFiles[i];

			if (!ns.fileExists(script, this.hostname)) {
				const res = await ns.scp(script, 'home', this.hostname);

				if (res) {
					Common.say(ns, 'Installed', this.hostname, script);
				}
			}
		}
	}

	/**
	 * Uninstalls hacking tools from this server.
	 */
	async uninstallTools() {
		if ('home' === this.hostname) {
			return;
		}

		// Delete files from server.
		for (let i = 0; i < toolFiles.length; i++) {
			const script = toolFiles[i];

			if (ns.fileExists(script, this.hostname)) {
				ns.scriptKill(script, this.hostname);
				const res = ns.rm(script, this.hostname);

				if (res) {
					Common.say(ns, 'Uninstalled', this.hostname, script);
				}
			}
		}
	}


	/**
	 * Starts all stopped services on this machine.
	 */
	startServices() {
		for (let i = 0; i < serviceFiles.length; i++) {
			const script = serviceFiles[i];

			if (
				ns.fileExists(script, this.hostname)
				&& !ns.isRunning(script, this.hostname)
			) {
				Common.say(ns, 'Start service', script);
				ns.exec(script, this.hostname);
			}
		}
	}

	/**
	 * Stops all running services on this machine.
	 */
	stopServices() {
		for (let i = 0; i < serviceFiles.length; i++) {
			const script = serviceFiles[i];

			if (ns.isRunning(script, this.hostname)) {
				Common.say(ns, 'Stop service', script);
				ns.kill(script, this.hostname);
			}
		}
	}

	/**
	 * Calculate maxumum number of threads a given script
	 * can take up on the current server.
	 */
	calcThreads(script) {
		if (!ns.fileExists(script, this.hostname)) {
			return 0;
		}

		const ramNeeded = ns.getScriptRam(script, this.hostname);

		return Math.max(0, Math.floor(this.ramFree / ramNeeded));
	}

	/**
	 * Allocate the given percentage of RAM to the specified
	 * worker types.
	 */
	setWorkers(pctWeaken, pctGrow) {

	}
}