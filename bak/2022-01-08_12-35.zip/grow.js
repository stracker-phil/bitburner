import * as Common from 'common.js';
import * as Server from 'server.js';
import * as Player from 'player.js';

/**
 * The attack and script configuration.
 */
let config = {};

/**
 * Player instance.
 */
const player = Player.get();

/** 
 * Autonomous growth script that purchases or
 * upgrades servers/hacknodes, buys programs
 * or performs non-hacking tasks.
 * 
 * @param {NS} ns
 */
export async function main(ns) {
	/**
	 * The main netscript API interface must be
	 * available in all functions.
	 * 
	 * @param {NS} ns
	 */
	window.ns = ns;

	Server.add('home', []);

	while (true) {
		config = Common.getConfig(ns);

		growNetwork();
		workOnTasks();

		await ns.sleep(5000);
	}
}

/**
 * Automatically upgrades servers and nodes or purchases
 * new elements when possible.
 * 
 * This function will constantly extend the server/node
 * network with following rules:
 * 
 * 1. Purchase new servers with minimal RAM, until the 
 *    server limit is reached
 * 2. Determine costs of the following actions:
 *    - Upgrade server RAM (delete + purchase new server)
 *    - New Hacknet Node
 *    - Hacknet Node RAM Update
 *    - Hacknet Node Level Update
 *    - Hacknet Node Core Update
 *    - Hacknet Server Cache Update
 * 3. Purchase programs
 *    - TOR access
 * 
 * This function will process all affordable
 * updates.
 */
function growNetwork() {
	player.refresh();

	const upgrades = getAvailableUpgrades();
	const initialBalance = player.money;

	let success = true;
	let doInstall = false;
	let count = 0;

	while (success) {
		player.refresh();
		const budget = parseInt(player.get('money') - config.autoGrow);

		let select = null;

		// Find the next upgrade to purchase.
		for (let i = 0; i < upgrades.length; i++) {
			const upgrade = upgrades[i];

			// Skip options that we cannot afford.
			if (upgrade.cost > budget) {
				continue;
			}

			if (!select || upgrade.cost < select.cost) {
				select = upgrade;
			}
		}

		// Stop, if no affordable upgrade exists.
		if (!select) {
			const spent = initialBalance - player.get('money');

			Common.log(
				ns,
				'No more affordable upgrades',
				`Purchased ${count} upgraded (\$ ${spent.toLocaleString()})`,
				`Budget: ${budget.toLocaleString()}`,
				`Locked budget: ${config.autoGrow.toLocaleString()}`
			);
			break;
		}

		// Purchase the upgrade.
		switch (select.action) {
			case 'add_server':
				Common.say(ns, `Purchase new Server: ${select.name} [${select.ram} GB]`);
				success = Server.purchase(select.name, select.ram);
				break;
			case 'upg_server':
				Common.say(ns, `Upgrade Server: ${select.name} [${select.ram} GB]`);
				success = Server.upgrade(select.name, select.ram);
				break;
			case 'add_node':
				Common.say(ns, `Purchase Hacknet Node`);
				success = -1 !== ns.hacknet.purchaseNode();
				break;
			case 'upg_node_lvl':
				Common.say(ns, `Upgrade Hacknet Level: Node ${select.index} [+${select.step}]`);
				success = ns.hacknet.upgradeLevel(select.index, select.step);
				break;
			case 'upg_node_ram':
				Common.say(ns, `Upgrade Hacknet RAM: Node ${select.index} [+${select.step}]`);
				success = ns.hacknet.upgradeRam(select.index, select.step);
				break;
			case 'upg_node_cre':
				Common.say(ns, `Upgrade Hacknet Cores: Node ${select.index} [+${select.step}]`);
				success = ns.hacknet.upgradeCore(select.index, select.step);
				break;
			case 'buy_tor':
				Common.say(ns, `Purchase TOR router`);
				success = ns.purchaseTor();
				break;
			case 'buy_program':
				Common.say(ns, `Purchase program in darkweb: ${select.name}`);
				// TODO: Requires NS-4
				// success = ns.purchaseProgram(select.name);
				// doInstall = true;
				break;
		}

		if (success) {
			count++;
		}
	}
}

/**
 * Start to work on specific tasks, such as
 * writing a program, comming crimes or visiting
 * a gym.
 * 
 * TODO: Require 256 GB home RAM for this.
 */
function workOnTasks() {
	/*
	if (ns.isBusy()) {
		return;
	}

	const tasks = getAvailableTasks(ns);

	let select = null;

	for (let i = 0; i < tasks.length; i++) {
		const task = tasks[i];

		// Prefer to write programs when possible.
		if ('write_program' === task.action) {
			select = task;
			break;
		}
	}

	if (!select) {
		return;
	}

	switch (select.action) {
		case 'write_program':
			Common.say(ns, `Start writing a program: ${select.name}`);
			ns.createProgram(select.name);
			break;
	}
	// */
}

/**
 * Collects a list of all possible upgrades and their 
 * costs.
 */
function getAvailableUpgrades() {
	const serverMaxRam = ns.getPurchasedServerMaxRam();
	const serverMaxNum = ns.getPurchasedServerLimit();
	const serverList = ns.getPurchasedServers();
	const nodesCount = ns.hacknet.numNodes();
	const nodesMax = ns.hacknet.maxNumNodes();
	const serverInitRam = 4;
	const nodeStepLevel = 10;
	const nodeStepRam = 5;
	const nodeStepCore = 5;
	const actions = [];

	// Purchase new servers.
	if (serverList.length < serverMaxNum) {
		actions.push({
			action: 'add_server',
			cost: ns.getPurchasedServerCost(serverInitRam),
			name: `pserv-${serverList.length}`,
			ram: serverInitRam
		});
	}

	// Upgrade existing servers.
	for (let i = 0; i < serverList.length; i++) {
		const name = serverList[i];
		const currRam = Server.get(name, 'maxRam');
		const newRam = 4 + currRam;

		if (newRam && !isNaN(newRam) && newRam < serverMaxRam) {
			actions.push({
				action: 'upg_server',
				cost: ns.getPurchasedServerCost(newRam),
				name,
				ram: newRam
			});
		}
	}

	// Purchase new hacknet nodes.
	if (nodesCount < nodesMax) {
		actions.push({
			action: 'add_node',
			cost: ns.hacknet.getPurchaseNodeCost()
		});
	}

	// Update existing hacknet nodes.
	for (let i = 0; i < nodesCount; i++) {
		const costLevel = ns.hacknet.getLevelUpgradeCost(i, nodeStepLevel);
		const costRam = ns.hacknet.getRamUpgradeCost(i, nodeStepCore);
		const costCore = ns.hacknet.getCoreUpgradeCost(i, nodeStepRam);

		if (costLevel && costLevel !== Infinity) {
			actions.push({
				action: 'upg_node_lvl',
				cost: costLevel,
				index: i,
				step: nodeStepLevel
			});
		}
		if (costRam && costRam !== Infinity) {
			actions.push({
				action: 'upg_node_ram',
				cost: costRam,
				index: i,
				step: nodeStepRam
			});
		}
		if (costCore && costCore !== Infinity) {
			actions.push({
				action: 'upg_node_cre',
				cost: costCore,
				index: i,
				step: nodeStepCore
			});
		}
	}

	// Purchase missing programs.
	if (!player.get('tor')) {
		actions.push({
			action: 'buy_tor',
			cost: 200000
		});
	} else {
		// TODO: Requires NS-4
		/*
		Common.hackingTools.forEach(tool => {
			if (!ns.fileExists(tool.file, 'home')) {
				actions.push({
					action: 'buy_program',
					cost: tool.cost,
					name: tool.file,
				});
			}
		});
		*/
	}

	return actions;
}

/**
 * Generates a list of possible tasks to do.
 * 
 * TODO: Require 256 GB home RAM for this.
 */
function getAvailableTasks(ns) {
	/*
	const char = ns.getStats();
	const tasks = [];

	// Create missing programs.
	Common.hackingTools.forEach(tool => {
		if (
			!ns.fileExists(tool.file, 'home')
			&& tool.level
			&& player.get('hacking') >= tool.level
		) {
			tasks.push({
				action: 'write_program',
				name: tool.file,
			});
		}
	});

	return tasks;
	// */
}