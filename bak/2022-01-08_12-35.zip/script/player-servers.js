import * as Common from '/script/common.js';

function updateServer(ns, serverMap, host) {
	serverMap.servers[host] = {
		host,
		ports: ns.getServerNumPortsRequired(host),
		hackingLevel: ns.getServerRequiredHackingLevel(host),
		maxMoney: ns.getServerMaxMoney(host),
		growth: ns.getServerGrowth(host),
		minSecurityLevel: ns.getServerMinSecurityLevel(host),
		baseSecurityLevel: ns.getServerBaseSecurityLevel(host),
		ram: ns.getServerRam(host)[0],
		connections: ['home'],
		parent: 'home',
		children: [],
	}

	Object.keys(serverMap.servers).map((hostname) => {
		if (!ns.serverExists(hostname)) {
			delete serverMap.servers[hostname]
		}
	})

	Common.setItem(Common.settings.keys.serverMap, serverMap)
}

function getPurchasedServers(ns) {
	let purchasedServers = ns.getPurchasedServers()
	if (purchasedServers.length) {
		purchasedServers.sort((a, b) => {
			const totalRamA = ns.getServerRam(a).shift()
			const totalRamB = ns.getServerRam(b).shift()

			if (totalRamA === totalRamB) {
				return ns.getServerRam(a).shift() - ns.getServerRam(b).shift()
			} else {
				return totalRamA - totalRamB
			}
		})
	}

	return purchasedServers
}

export async function main(ns) {
	ns.tprint(`[${Common.timestamp()}] Starting player-servers.js`)

	Common.fromHome(ns);

	Common.settings.maxGbRam = ns.getPurchasedServerMaxRam()
	Common.settings.maxPlayerServers = ns.getPurchasedServerLimit()

	while (true) {
		let didChange = false

		const serverMap = Common.getItem(Common.settings.keys.serverMap)
		let purchasedServers = getPurchasedServers(ns)

		let action = purchasedServers.length < Common.settings.maxPlayerServers ? Common.settings.actions.BUY : Common.settings.actions.UPGRADE

		if (action == Common.settings.actions.BUY) {
			let smallestCurrentServer = purchasedServers.length ? ns.getServerRam(purchasedServers[0]).shift() : 0
			let targetRam = Math.max(Common.settings.minGbRam, smallestCurrentServer)

			if (targetRam === Common.settings.minGbRam) {
				while (ns.getServerMoneyAvailable('home') * Common.settings.totalMoneyAllocation >= targetRam * Common.settings.gbRamCost * Common.settings.maxPlayerServers) {
					targetRam *= 2
				}

				targetRam /= 2
			}

			targetRam = Math.max(Common.settings.minGbRam, targetRam)
			targetRam = Math.min(targetRam, Common.settings.maxGbRam)

			if (ns.getServerMoneyAvailable('home') * Common.settings.totalMoneyAllocation >= targetRam * Common.settings.gbRamCost) {
				let hostname = `pserv-${targetRam}-${Common.createUUID()}`
				hostname = ns.purchaseServer(hostname, targetRam)

				if (hostname) {
					ns.tprint(`[${Common.timestamp()}] Bought new server: ${hostname} (${targetRam} GB)`)

					updateServer(ns, serverMap, hostname)
					didChange = true
				}
			}
		} else {
			let smallestCurrentServer = Math.max(ns.getServerRam(purchasedServers[0]).shift(), Common.settings.minGbRam)
			let biggestCurrentServer = ns.getServerRam(purchasedServers[purchasedServers.length - 1]).shift()
			let targetRam = biggestCurrentServer

			if (smallestCurrentServer === Common.settings.maxGbRam) {
				ns.tprint(`[${Common.timestamp()}] All servers maxxed. Exiting.`)
				ns.exit()
				return
			}

			if (smallestCurrentServer === biggestCurrentServer) {
				while (ns.getServerMoneyAvailable('home') * Common.settings.totalMoneyAllocation >= targetRam * Common.settings.gbRamCost) {
					targetRam *= 4
				}

				targetRam /= 4
			}

			targetRam = Math.min(targetRam, Common.settings.maxGbRam)

			purchasedServers = getPurchasedServers(ns)
			if (targetRam > ns.getServerRam(purchasedServers[0]).shift()) {
				didChange = true
				while (didChange) {
					didChange = false
					purchasedServers = getPurchasedServers(ns)

					if (targetRam > ns.getServerRam(purchasedServers[0]).shift()) {
						if (ns.getServerMoneyAvailable('home') * Common.settings.totalMoneyAllocation >= targetRam * Common.settings.gbRamCost) {
							let hostname = `pserv-${targetRam}-${Common.createUUID()}`

							await ns.killall(purchasedServers[0])
							await ns.sleep(10)
							const serverDeleted = await ns.deleteServer(purchasedServers[0])
							if (serverDeleted) {
								hostname = await ns.purchaseServer(hostname, targetRam)

								if (hostname) {
									ns.tprint(`[${Common.timestamp()}] Upgraded: ${purchasedServers[0]} into server: ${hostname} (${targetRam} GB)`)

									updateServer(ns, serverMap, hostname)
									didChange = true
								}
							}
						}
					}
				}
			}
		}

		if (!didChange) {
			await ns.sleep(5123)
		}
	}
}